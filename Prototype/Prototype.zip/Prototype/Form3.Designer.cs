﻿
namespace Prototype
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbPDate = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.pbReceipt = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbRemarks = new System.Windows.Forms.TextBox();
            this.lbUsedDate = new System.Windows.Forms.Label();
            this.lbCost = new System.Windows.Forms.Label();
            this.lbSummary = new System.Windows.Forms.Label();
            this.lbMoney = new System.Windows.Forms.Label();
            this.btApproval = new System.Windows.Forms.Button();
            this.btAgain = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbReceipt)).BeginInit();
            this.SuspendLayout();
            // 
            // lbPDate
            // 
            this.lbPDate.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbPDate.Location = new System.Drawing.Point(12, 9);
            this.lbPDate.Name = "lbPDate";
            this.lbPDate.Size = new System.Drawing.Size(155, 26);
            this.lbPDate.TabIndex = 0;
            this.lbPDate.Text = "＿＿年＿月＿＿日";
            // 
            // lbName
            // 
            this.lbName.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbName.Location = new System.Drawing.Point(360, 48);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(114, 22);
            this.lbName.TabIndex = 1;
            this.lbName.Text = "○○○○";
            // 
            // pbReceipt
            // 
            this.pbReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbReceipt.Location = new System.Drawing.Point(287, 73);
            this.pbReceipt.Name = "pbReceipt";
            this.pbReceipt.Size = new System.Drawing.Size(187, 277);
            this.pbReceipt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReceipt.TabIndex = 2;
            this.pbReceipt.TabStop = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(12, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 22);
            this.label3.TabIndex = 3;
            this.label3.Text = "日付：";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(12, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 22);
            this.label4.TabIndex = 4;
            this.label4.Text = "備考：";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(12, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 22);
            this.label5.TabIndex = 5;
            this.label5.Text = "金額：";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label6.Location = new System.Drawing.Point(12, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 22);
            this.label6.TabIndex = 6;
            this.label6.Text = "概要：";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label7.Location = new System.Drawing.Point(12, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 22);
            this.label7.TabIndex = 7;
            this.label7.Text = "項目：";
            // 
            // tbRemarks
            // 
            this.tbRemarks.Location = new System.Drawing.Point(66, 268);
            this.tbRemarks.Multiline = true;
            this.tbRemarks.Name = "tbRemarks";
            this.tbRemarks.Size = new System.Drawing.Size(203, 153);
            this.tbRemarks.TabIndex = 8;
            // 
            // lbUsedDate
            // 
            this.lbUsedDate.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbUsedDate.Location = new System.Drawing.Point(66, 69);
            this.lbUsedDate.Name = "lbUsedDate";
            this.lbUsedDate.Size = new System.Drawing.Size(186, 26);
            this.lbUsedDate.TabIndex = 9;
            this.lbUsedDate.Text = "＿＿年＿月＿日";
            // 
            // lbCost
            // 
            this.lbCost.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbCost.Location = new System.Drawing.Point(66, 105);
            this.lbCost.Name = "lbCost";
            this.lbCost.Size = new System.Drawing.Size(186, 26);
            this.lbCost.TabIndex = 10;
            this.lbCost.Text = "■■費";
            // 
            // lbSummary
            // 
            this.lbSummary.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbSummary.Location = new System.Drawing.Point(66, 139);
            this.lbSummary.Name = "lbSummary";
            this.lbSummary.Size = new System.Drawing.Size(186, 81);
            this.lbSummary.TabIndex = 11;
            this.lbSummary.Text = "１.";
            // 
            // lbMoney
            // 
            this.lbMoney.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbMoney.Location = new System.Drawing.Point(66, 228);
            this.lbMoney.Name = "lbMoney";
            this.lbMoney.Size = new System.Drawing.Size(186, 26);
            this.lbMoney.TabIndex = 12;
            this.lbMoney.Text = "００００００円";
            // 
            // btApproval
            // 
            this.btApproval.Location = new System.Drawing.Point(287, 379);
            this.btApproval.Name = "btApproval";
            this.btApproval.Size = new System.Drawing.Size(88, 42);
            this.btApproval.TabIndex = 13;
            this.btApproval.Text = "承認";
            this.btApproval.UseVisualStyleBackColor = true;
            // 
            // btAgain
            // 
            this.btAgain.Location = new System.Drawing.Point(390, 379);
            this.btAgain.Name = "btAgain";
            this.btAgain.Size = new System.Drawing.Size(88, 42);
            this.btAgain.TabIndex = 14;
            this.btAgain.Text = "再提出";
            this.btAgain.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(306, 48);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 22);
            this.label12.TabIndex = 15;
            this.label12.Text = "氏名：";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(486, 435);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btAgain);
            this.Controls.Add(this.btApproval);
            this.Controls.Add(this.lbMoney);
            this.Controls.Add(this.lbSummary);
            this.Controls.Add(this.lbCost);
            this.Controls.Add(this.lbUsedDate);
            this.Controls.Add(this.tbRemarks);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pbReceipt);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.lbPDate);
            this.Name = "Form3";
            this.Text = "確認画面";
            ((System.ComponentModel.ISupportInitialize)(this.pbReceipt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbPDate;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.PictureBox pbReceipt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbRemarks;
        private System.Windows.Forms.Label lbUsedDate;
        private System.Windows.Forms.Label lbCost;
        private System.Windows.Forms.Label lbSummary;
        private System.Windows.Forms.Label lbMoney;
        private System.Windows.Forms.Button btApproval;
        private System.Windows.Forms.Button btAgain;
        private System.Windows.Forms.Label label12;
    }
}